import React, {Component} from 'react';
import axios from 'axios'

class Table extends Component{
  state={
    posts:[]
  }
  componentDidMount(){
    axios.get('https://jsonplaceholder.typicode.com/users')
    .then(response=>{
        this.setState({posts:response.data})
    });
  }
  render(){
    const posts=this.state.posts.map(post=>{
      return <div key={post.id}>{post.name}</div>
    });
    return (
      <div>
          {posts}
      </div>
    )
  }
}

export default Table;
